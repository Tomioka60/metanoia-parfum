/**
 * Utility functions for perfume image processing, compression, and presets.
 */

export interface PerfumePhotoPreset {
  id: string;
  name: string;
  category: string;
  url: string;
  accent: string;
}

export const CURATED_PERFUME_PHOTOS: PerfumePhotoPreset[] = [
  {
    id: 'preset-oud-noir',
    name: 'Oud Mystique Noir',
    category: 'Boisé / Oriental',
    url: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=900&q=80',
    accent: '#D8B08C',
  },
  {
    id: 'preset-ambre-dore',
    name: 'Ambre Impérial Doré',
    category: 'Ambré / Chaleureux',
    url: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=900&q=80',
    accent: '#C9A46C',
  },
  {
    id: 'preset-rose-velours',
    name: 'Rose & Épices Précieuses',
    category: 'Floral / Rose',
    url: 'https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=900&q=80',
    accent: '#C98F78',
  },
  {
    id: 'preset-cuir-sombre',
    name: 'Cuir Fumé & Encens',
    category: 'Cuiré / Fumé',
    url: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=900&q=80',
    accent: '#A67B5B',
  },
  {
    id: 'preset-neroli-lumineux',
    name: 'Néroli & Fleur d’Oranger',
    category: 'Frais / Agrumes',
    url: 'https://images.unsplash.com/photo-1615634260167-c8cdede054de?auto=format&fit=crop&w=900&q=80',
    accent: '#DEC291',
  },
  {
    id: 'preset-vanille-cristal',
    name: 'Vanille Noire & Tonka',
    category: 'Gourmand / Vanille',
    url: 'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=900&q=80',
    accent: '#D8B08C',
  },
  {
    id: 'preset-iris-blanc',
    name: 'Iris Poudré & Musc Blanc',
    category: 'Poudré / Floral',
    url: 'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=900&q=80',
    accent: '#E5D6C5',
  },
  {
    id: 'preset-boise-vintage',
    name: 'Cèdre Noble & Vétiver',
    category: 'Boisé / Terrestre',
    url: 'https://images.unsplash.com/photo-1582211594533-268f4f1edcb9?auto=format&fit=crop&w=900&q=80',
    accent: '#B08968',
  },
];

/**
 * Resizes and compresses an image file to a lightweight data URL
 * so it can be saved in local storage without crashing storage quotas.
 */
export async function compressAndFormatImage(
  file: File,
  maxDimension = 1200,
  quality = 0.85
): Promise<string> {
  return new Promise((resolve, reject) => {
    // Basic format check
    if (!file.type.startsWith('image/')) {
      reject(new Error('Le fichier sélectionné n’est pas une image valide.'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Erreur lors de la lecture du fichier.'));
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Impossible de charger l’image pour le traitement.'));
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Downscale while preserving aspect ratio if larger than maxDimension
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          // Fallback to original read result if canvas context fails
          resolve(e.target?.result as string);
          return;
        }

        // Draw image smoothly
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Convert to web-friendly JPEG data URL
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };

      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Validates if an image URL is well-formed.
 */
export function isValidImageUrl(url?: string | null): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (trimmed.startsWith('data:image/')) return true;
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return true;
  if (trimmed.startsWith('/')) return true;
  return false;
}
